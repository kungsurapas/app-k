const mongoose = require('mongoose');

const replaceSchema = new mongoose.Schema({
  No: Number,
  Site: String,
  NewSite: String,
  Lot: String,
  EQCode: String,
  NEWEQ: String,
DateOfReplace: String,
  NewOwnerID: Number,
  NewOwnerName: String,
  NewOwnerSurName: String,
  NewOwnerMobile: String,
'ContractID':String,
  ContractName: String,
  ContractSurname: String,
 ContractMobilePhone: String
   
  
});

// ชื่อ collection ที่ใช้ใน MongoDB = 're'
module.exports = mongoose.model('Replace', replaceSchema, 're');





